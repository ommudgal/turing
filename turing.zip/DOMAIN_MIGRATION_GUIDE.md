# Domain Migration Summary: mlcoe.live → mlcoe.tech

## Overview
This document summarizes the changes made to migrate from `mlcoe.live` to `mlcoe.tech` with automatic forwarding.

## Changes Made

### 1. Nginx Configuration (`nginx/conf.d/default.conf`)
- **Main domain changed**: `mlcoe.live` → `mlcoe.tech`
- **Added forwarding**: All traffic from `mlcoe.live` redirects to `mlcoe.tech`
- **SSL certificates**: Updated paths to use `mlcoe.tech` certificates
- **HTTP redirects**: Both domains redirect HTTP to HTTPS
- **Maintains**: All rate limiting and security configurations

### 2. Docker Compose (`docker-compose.yml`)
- **API URL updated**: `REACT_APP_API_URL=https://mlcoe.tech/api/v1`

### 3. Frontend Components
- **Input.js**: API URL fallback changed to `mlcoe.tech`
- **Verification.js**: API URL fallback changed to `mlcoe.tech`

### 4. Deployment Scripts
- **deploy_rate_limiting.bat**: Updated server hostname and test URLs
- **setup_ssl.bat**: Updated domain references
- **setup_ssl.sh**: Updated domain references  
- **test_rate_limiting.bat**: Updated all test endpoints

### 5. Documentation
- **SSL_SETUP_GUIDE.md**: Updated all domain references

### 6. New Scripts Created
- **setup_ssl_both_domains.bat**: Sets up SSL for both domains
- **deploy_domain_change.bat**: Complete deployment script for domain migration
- **test_domain_forwarding.bat**: Tests all redirect scenarios

## Traffic Flow

### Before Migration
```
User → mlcoe.live → Website
```

### After Migration
```
User → mlcoe.tech → Website (direct)
User → mlcoe.live → 301 redirect → mlcoe.tech → Website (forwarded)
```

## Redirect Matrix

| User visits | HTTP redirects to | HTTPS redirects to | Final result |
|-------------|-------------------|-------------------|--------------|
| http://mlcoe.tech | https://mlcoe.tech | - | Website loads |
| https://mlcoe.tech | - | - | Website loads |
| http://mlcoe.live | https://mlcoe.live | https://mlcoe.tech | Website loads |
| https://mlcoe.live | - | https://mlcoe.tech | Website loads |

## SSL Certificate Requirements

The nginx configuration requires SSL certificates for both domains:

1. **Primary**: `/etc/letsencrypt/live/mlcoe.tech/`
   - `fullchain.pem`
   - `privkey.pem`

2. **Forwarding**: `/etc/letsencrypt/live/mlcoe.live/` 
   - `fullchain.pem` 
   - `privkey.pem`

## Deployment Steps

1. **Prepare**: Ensure both domains point to your server IP
2. **Deploy**: Run `deploy_domain_change.bat`
3. **Verify**: Run `test_domain_forwarding.bat`
4. **Monitor**: Check logs and service status

## Testing Commands

```bash
# Test main domain
curl -I https://mlcoe.tech/

# Test forwarding
curl -I https://mlcoe.live/

# Test API
curl https://mlcoe.tech/api/v1/health

# Check redirect chain
curl -I -L http://mlcoe.live/
```

## Rollback Plan

If issues occur, restore the backed-up configuration:

```bash
ssh -i yoga.pem ubuntu@mlcoe.tech
cd mlcoe
cp nginx/conf.d/default.conf.backup.YYYYMMDD nginx/conf.d/default.conf
docker-compose restart nginx
```

## SEO Considerations

- **301 Redirects**: Preserve search engine rankings
- **Canonical URLs**: Update any hardcoded links to use `mlcoe.tech`
- **Search Console**: Add new domain property for `mlcoe.tech`
- **Analytics**: Update tracking for new domain

## Monitoring

After deployment, monitor:
- SSL certificate expiration dates
- Redirect performance
- Search engine crawling
- User traffic patterns
- Error logs for 404s or broken redirects

## Next Steps

1. **Update DNS**: Ensure both domains point to server
2. **Deploy**: Execute domain migration scripts
3. **Test**: Verify all redirect scenarios
4. **Monitor**: Watch for any issues in the first 24-48 hours
5. **Update external references**: Update any external sites linking to old domain

#!/bin/bash
# SSL Setup Script for mlcoe.tech and mlcoe.live
# This script sets up SSL certificates for both domains in the turing project

set -e  # Exit on any error

echo "========================================="
echo "SSL Setup for Turing Project"
echo "========================================="
echo "Setting up SSL certificates for:"
echo "- mlcoe.tech (main domain)"
echo "- mlcoe.live (forwarding domain)"
echo

# Check if we're in the right directory
if [ ! -f "docker-compose.yml" ]; then
    echo "Error: docker-compose.yml not found!"
    echo "Please run this script from the /home/ec2-user/turing directory"
    exit 1
fi

echo "Step 1: Creating necessary directories..."
mkdir -p nginx/certbot/conf
mkdir -p nginx/certbot/www

echo "Step 2: Starting temporary services for certificate validation..."
# Stop any existing services
docker-compose down 2>/dev/null || true

# Start services
docker-compose up -d

echo "Waiting for services to be ready..."
sleep 15

echo "Step 3: Requesting SSL certificate for mlcoe.tech..."
docker run --rm \
  -v $(pwd)/nginx/certbot/conf:/etc/letsencrypt \
  -v $(pwd)/nginx/certbot/www:/var/www/certbot \
  certbot/certbot certonly \
  --webroot \
  --webroot-path=/var/www/certbot \
  --email admin@mlcoe.tech \
  --agree-tos \
  --no-eff-email \
  --non-interactive \
  -d mlcoe.tech

if [ -f "nginx/certbot/conf/live/mlcoe.tech/fullchain.pem" ]; then
    echo "✓ SSL certificate for mlcoe.tech created successfully!"
else
    echo "✗ Failed to create SSL certificate for mlcoe.tech"
    echo "Please check that mlcoe.tech points to this server's IP"
    exit 1
fi

echo "Step 4: Requesting SSL certificate for mlcoe.live..."
docker run --rm \
  -v $(pwd)/nginx/certbot/conf:/etc/letsencrypt \
  -v $(pwd)/nginx/certbot/www:/var/www/certbot \
  certbot/certbot certonly \
  --webroot \
  --webroot-path=/var/www/certbot \
  --email admin@mlcoe.tech \
  --agree-tos \
  --no-eff-email \
  --non-interactive \
  -d mlcoe.live

if [ -f "nginx/certbot/conf/live/mlcoe.live/fullchain.pem" ]; then
    echo "✓ SSL certificate for mlcoe.live created successfully!"
else
    echo "⚠ Failed to create SSL certificate for mlcoe.live"
    echo "This is optional for forwarding, continuing..."
fi

echo "Step 5: Restarting services with SSL configuration..."
docker-compose down
docker-compose up -d

echo "Step 6: Waiting for services to start..."
sleep 10

echo "Step 7: Checking service status..."
docker-compose ps

echo
echo "========================================="
echo "SSL Setup Complete!"
echo "========================================="
echo
echo "Certificate locations:"
echo "- mlcoe.tech: nginx/certbot/conf/live/mlcoe.tech/"
echo "- mlcoe.live: nginx/certbot/conf/live/mlcoe.live/"
echo
echo "Your site should now be available at:"
echo "- https://mlcoe.tech (main domain)"
echo "- https://mlcoe.live (redirects to mlcoe.tech)"
echo
echo "Test commands:"
echo "curl -I https://mlcoe.tech/"
echo "curl -I https://mlcoe.live/"
echo
echo "To renew certificates:"
echo "docker-compose exec nginx certbot renew"
echo

# Test the setup
echo "Testing HTTPS setup..."
sleep 5

if curl -f -s -I https://mlcoe.tech/ > /dev/null 2>&1; then
    echo "✓ Main domain (mlcoe.tech) is working!"
else
    echo "⚠ Main domain test failed - check logs:"
    echo "docker-compose logs nginx"
fi

if curl -f -s -I https://mlcoe.live/ > /dev/null 2>&1; then
    echo "✓ Forwarding domain (mlcoe.live) is working!"
else
    echo "⚠ Forwarding domain test failed - this may be normal if redirecting"
fi

echo
echo "Setup complete! Check 'docker-compose logs' if you encounter any issues."

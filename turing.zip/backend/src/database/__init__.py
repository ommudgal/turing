# Database module for MongoDB integration
